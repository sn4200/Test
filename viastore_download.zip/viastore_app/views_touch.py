from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import GoodsReceiptForm
from .models import Item

@login_required
def touch_main(request):
    message = None
    if request.method == "POST":
        form = GoodsReceiptForm(request.POST)
        if form.is_valid():
            item = form.cleaned_data["item"]
            quantity = form.cleaned_data["quantity"]
            item.quantity += quantity
            item.save()
            message = f"Wareneingang für {item.name} ({item.sku}) erfolgreich gebucht!"
            form = GoodsReceiptForm()
    else:
        form = GoodsReceiptForm()
    return render(request, "goods_receipt_touch.html", {"form": form, "title": "Wareneingang Touch", "message": message, "standalone": True})
